import type React from "react"
import { AuthProvider } from "@/components/auth/auth-provider"

export default function AuthLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-gray-50">
      <AuthProvider>{children}</AuthProvider>
    </div>
  )
}

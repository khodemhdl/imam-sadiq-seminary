"use client"

import { BookOpen } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function AuthPortal() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 bg-[#0a5c45] rounded-full flex items-center justify-center text-white">
            <BookOpen className="w-10 h-10" />
          </div>
        </div>

        <Card>
          <CardHeader className="space-y-1 text-center">
            <CardTitle className="text-2xl font-bold">پورتال مدیریت</CardTitle>
            <CardDescription>مدرسه علمیه امام صادق (ع)</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-4">
            <p className="text-center text-sm text-gray-600 mb-2">
              به پورتال مدیریت مدرسه علمیه امام صادق (ع) خوش آمدید. لطفاً برای ادامه، وارد سیستم شوید.
            </p>
            <Link href="/auth/login" className="w-full">
              <Button className="w-full bg-[#0a5c45] hover:bg-[#0a5c45]/90">ورود به سیستم</Button>
            </Link>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Link href="/" className="text-sm text-gray-500 hover:text-[#0a5c45]">
              بازگشت به صفحه اصلی
            </Link>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

import { ArrowRight, Calendar, User, Tag, Share2, Bookmark, MessageSquare } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

export default function ArticlePage({ params }: { params: { slug: string } }) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <Link href="/" className="text-[#0a5c45] hover:underline flex items-center">
              <ArrowRight className="ml-2 w-4 h-4" />
              بازگشت به صفحه اصلی
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Article Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              بررسی تطبیقی آرای علامه طباطبایی و شهید مطهری در باب عدالت اجتماعی
            </h1>

            <div className="flex flex-wrap items-center text-sm text-gray-500 mb-6 gap-4">
              <div className="flex items-center">
                <Calendar className="ml-1 w-4 h-4" />
                <span>۱۴۰۲/۱۲/۰۱</span>
              </div>
              <div className="flex items-center">
                <User className="ml-1 w-4 h-4" />
                <span>دکتر محمدی</span>
              </div>
              <div className="flex items-center">
                <Tag className="ml-1 w-4 h-4" />
                <span>فلسفه اسلامی</span>
              </div>
            </div>

            <div className="relative aspect-[2/1] rounded-lg overflow-hidden mb-6">
              <Image
                src="/placeholder.svg?height=400&width=800"
                alt="تصویر مقاله"
                width={800}
                height={400}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Article Content */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <div className="prose prose-lg max-w-none leading-relaxed">
              <p>بسم الله الرحمن الرحیم</p>
              <p>
                عدالت اجتماعی یکی از مهم‌ترین مباحث در اندیشه اسلامی است که همواره مورد توجه اندیشمندان مسلمان قرار داشته
                است. در میان متفکران معاصر، علامه طباطبایی و شهید مطهری از جمله اندیشمندانی هستند که به طور جدی به این
                موضوع پرداخته‌اند. این مقاله به بررسی تطبیقی دیدگاه‌های این دو اندیشمند بزرگ در خصوص مفهوم عدالت اجتماعی
                از منظر اسلام می‌پردازد.
              </p>

              <h2>مفهوم عدالت از دیدگاه علامه طباطبایی</h2>
              <p>
                علامه طباطبایی در تفسیر المیزان، عدالت را به معنای قرار دادن هر چیز در جای خود می‌داند. از نظر ایشان،
                عدالت اجتماعی زمانی محقق می‌شود که هر فرد در جامعه در جایگاه شایسته خود قرار گیرد و حقوق افراد به طور
                کامل رعایت شود. علامه طباطبایی با استناد به آیات قرآن کریم، عدالت را یکی از اصول اساسی حکومت اسلامی
                می‌داند و معتقد است که تحقق عدالت اجتماعی، هدف اصلی بعثت انبیاء الهی بوده است.
              </p>
              <p>
                از دیدگاه علامه، عدالت اجتماعی دارای ابعاد مختلفی است که شامل عدالت اقتصادی، عدالت سیاسی، عدالت فرهنگی و
                عدالت قضایی می‌شود. ایشان معتقد است که برای تحقق عدالت اجتماعی، باید همه این ابعاد مورد توجه قرار گیرد و
                نمی‌توان تنها به یک بعد از عدالت اکتفا کرد.
              </p>

              <h2>مفهوم عدالت از دیدگاه شهید مطهری</h2>
              <p>
                شهید مطهری نیز همچون علامه طباطبایی، عدالت را به معنای قرار دادن هر چیز در جای خود می‌داند، اما ایشان
                تعریف دقیق‌تری از عدالت ارائه می‌دهد. از نظر شهید مطهری، عدالت به معنای رعایت استحقاق‌ها در افاضه وجود و
                امتناع نکردن از افاضه و رحمت به آنچه امکان وجود یا کمال وجود دارد، می‌باشد.
              </p>
              <p>
                شهید مطهری با نقد نظریات مختلف درباره عدالت، از جمله نظریه عدالت به معنای تساوی، نظریه عدالت به معنای
                رعایت استحقاق‌ها را مطرح می‌کند و معتقد است که عدالت اجتماعی زمانی محقق می‌شود که استحقاق‌های افراد در جامعه
                رعایت شود. ایشان با استناد به آیات قرآن و روایات اهل بیت (ع)، عدالت را یکی از اصول اساسی حکومت اسلامی
                می‌داند.
              </p>

              <h2>مقایسه دیدگاه‌های علامه طباطبایی و شهید مطهری</h2>
              <p>
                با مقایسه دیدگاه‌های علامه طباطبایی و شهید مطهری درباره عدالت اجتماعی، می‌توان به نکات مشترک و تفاوت‌های
                دیدگاه این دو اندیشمند پی برد. هر دو اندیشمند، عدالت را به معنای قرار دادن هر چیز در جای خود می‌دانند و
                معتقدند که عدالت اجتماعی یکی از اهداف اصلی حکومت اسلامی است.
              </p>
              <p>
                اما تفاوت‌هایی نیز در دیدگاه‌های این دو اندیشمند وجود دارد. علامه طباطبایی بیشتر بر ابعاد مختلف عدالت
                اجتماعی تأکید می‌کند، در حالی که شهید مطهری بیشتر به تبیین مفهوم عدالت و نقد نظریات مختلف درباره عدالت
                می‌پردازد. همچنین، شهید مطهری با طرح نظریه عدالت به معنای رعایت استحقاق‌ها، تعریف دقیق‌تری از عدالت ارائه
                می‌دهد.
              </p>

              <h2>نتیجه‌گیری</h2>
              <p>
                با بررسی دیدگاه‌های علامه طباطبایی و شهید مطهری درباره عدالت اجتماعی، می‌توان به این نتیجه رسید که هر دو
                اندیشمند، عدالت را یکی از اصول اساسی حکومت اسلامی می‌دانند و معتقدند که تحقق عدالت اجتماعی، یکی از اهداف
                اصلی بعثت انبیاء الهی بوده است. هر دو اندیشمند، عدالت را به معنای قرار دادن هر چیز در جای خود می‌دانند،
                اما شهید مطهری با طرح نظریه عدالت به معنای رعایت استحقاق‌ها، تعریف دقیق‌تری از عدالت ارائه می‌دهد.
              </p>
              <p>
                در مجموع، می‌توان گفت که دیدگاه‌های علامه طباطبایی و شهید مطهری درباره عدالت اجتماعی، مکمل یکدیگر هستند و
                با مطالعه آثار این دو اندیشمند، می‌توان به درک عمیق‌تری از مفهوم عدالت اجتماعی از منظر اسلام دست یافت.
              </p>
            </div>
          </div>

          {/* Article Actions */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6 flex justify-between">
            <div className="flex space-x-4 rtl:space-x-reverse">
              <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                <Share2 className="ml-1 w-5 h-5" />
                <span>اشتراک‌گذاری</span>
              </button>
              <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                <Bookmark className="ml-1 w-5 h-5" />
                <span>ذخیره</span>
              </button>
            </div>
            <div>
              <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                <MessageSquare className="ml-1 w-5 h-5" />
                <span>نظرات (۵)</span>
              </button>
            </div>
          </div>

          {/* Related Articles */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-xl font-bold text-gray-800 mb-4">مقالات مرتبط</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex">
                <div className="w-24 h-24 bg-gray-100 rounded-md overflow-hidden ml-4 flex-shrink-0">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="تصویر مقاله"
                    width={96}
                    height={96}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1 hover:text-[#0a5c45]">
                    <Link href="#">تحلیلی بر روش‌های استنباط احکام فقهی در مسائل مستحدثه</Link>
                  </h4>
                  <p className="text-sm text-gray-500 mb-1">دکتر رضایی</p>
                  <p className="text-xs text-gray-400">۱۴۰۲/۱۱/۲۵</p>
                </div>
              </div>

              <div className="flex">
                <div className="w-24 h-24 bg-gray-100 rounded-md overflow-hidden ml-4 flex-shrink-0">
                  <Image
                    src="/placeholder.svg?height=96&width=96"
                    alt="تصویر مقاله"
                    width={96}
                    height={96}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1 hover:text-[#0a5c45]">
                    <Link href="#">جایگاه عقل در استنباط احکام شرعی</Link>
                  </h4>
                  <p className="text-sm text-gray-500 mb-1">دکتر حسینی</p>
                  <p className="text-xs text-gray-400">۱۴۰۲/۱۱/۱۵</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

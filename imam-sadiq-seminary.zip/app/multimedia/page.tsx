import { Search, Filter, Headphones, ChevronLeft } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function MultimediaPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <Link href="/" className="text-[#0a5c45] hover:underline flex items-center">
              <ChevronLeft className="ml-2 w-4 h-4" />
              بازگشت به صفحه اصلی
            </Link>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-8 text-center">کتابخانه چندرسانه‌ای</h1>

        {/* Search and Filter */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input placeholder="جستجو در محتوای چندرسانه‌ای..." className="pr-10 w-full" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center">
                <Filter className="ml-2 w-4 h-4" />
                فیلتر
              </Button>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="videos" className="mb-8">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="videos" className="text-base py-3">
              ویدیوها
            </TabsTrigger>
            <TabsTrigger value="audios" className="text-base py-3">
              فایل‌های صوتی
            </TabsTrigger>
          </TabsList>

          <TabsContent value="videos">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {/* Video Item 1 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۵۵:۲۰
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    جلسه اول: مبانی اصول فقه
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>استاد محمدی</span>
                    <span>۱۴۰۲/۱۲/۰۱</span>
                  </div>
                </div>
              </div>

              {/* Video Item 2 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۴۵:۱۵
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    کارگاه روش تحقیق در علوم اسلامی
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>دکتر حسینی</span>
                    <span>۱۴۰۲/۱۱/۲۵</span>
                  </div>
                </div>
              </div>

              {/* Video Item 3 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۶۰:۳۰
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    تفسیر آیات الاحکام
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>استاد رضایی</span>
                    <span>۱۴۰۲/۱۱/۱۵</span>
                  </div>
                </div>
              </div>

              {/* Video Item 4 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۴۰:۱۰
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    مباحث اخلاق اسلامی
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>دکتر علوی</span>
                    <span>۱۴۰۲/۱۱/۰۵</span>
                  </div>
                </div>
              </div>

              {/* Video Item 5 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۵۰:۲۵
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    همایش سالانه اصول فقه
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>گروه اساتید</span>
                    <span>۱۴۰۲/۱۰/۲۰</span>
                  </div>
                </div>
              </div>

              {/* Video Item 6 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden group">
                <div className="aspect-video relative">
                  <Image
                    src="/placeholder.svg?height=180&width=320"
                    alt="تصویر ویدیو"
                    width={320}
                    height={180}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[18px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                  <div className="absolute bottom-2 right-2 bg-[#0a5c45] text-white text-xs px-2 py-1 rounded">
                    ۳۵:۴۵
                  </div>
                </div>
                <div className="p-4">
                  <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                    روش‌شناسی تفسیر قرآن کریم
                  </h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>دکتر موسوی</span>
                    <span>۱۴۰۲/۱۰/۱۰</span>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="audios">
            <div className="space-y-4">
              {/* Audio Item 1 */}
              <div className="bg-white rounded-lg shadow-sm p-4 flex items-center">
                <div className="w-12 h-12 bg-[#0a5c45] rounded-full flex items-center justify-center ml-4 flex-shrink-0">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-gray-800 mb-1">سلسله مباحث تفسیر سوره بقره - جلسه اول</h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>استاد رضایی</span>
                    <span>۶۰ دقیقه</span>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-10 w-10 flex-shrink-0">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#0a5c45] border-b-[8px] border-b-transparent"></div>
                </Button>
              </div>

              {/* Audio Item 2 */}
              <div className="bg-white rounded-lg shadow-sm p-4 flex items-center">
                <div className="w-12 h-12 bg-[#0a5c45] rounded-full flex items-center justify-center ml-4 flex-shrink-0">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-gray-800 mb-1">سلسله مباحث تفسیر سوره بقره - جلسه دوم</h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>استاد رضایی</span>
                    <span>۵۵ دقیقه</span>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-10 w-10 flex-shrink-0">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#0a5c45] border-b-[8px] border-b-transparent"></div>
                </Button>
              </div>

              {/* Audio Item 3 */}
              <div className="bg-white rounded-lg shadow-sm p-4 flex items-center">
                <div className="w-12 h-12 bg-[#0a5c45] rounded-full flex items-center justify-center ml-4 flex-shrink-0">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-gray-800 mb-1">سلسله مباحث تفسیر سوره بقره - جلسه سوم</h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>استاد رضایی</span>
                    <span>۵۸ دقیقه</span>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-10 w-10 flex-shrink-0">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#0a5c45] border-b-[8px] border-b-transparent"></div>
                </Button>
              </div>

              {/* Audio Item 4 */}
              <div className="bg-white rounded-lg shadow-sm p-4 flex items-center">
                <div className="w-12 h-12 bg-[#0a5c45] rounded-full flex items-center justify-center ml-4 flex-shrink-0">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-gray-800 mb-1">درس‌های اخلاق اسلامی - جلسه اول</h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>دکتر علوی</span>
                    <span>۴۵ دقیقه</span>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-10 w-10 flex-shrink-0">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#0a5c45] border-b-[8px] border-b-transparent"></div>
                </Button>
              </div>

              {/* Audio Item 5 */}
              <div className="bg-white rounded-lg shadow-sm p-4 flex items-center">
                <div className="w-12 h-12 bg-[#0a5c45] rounded-full flex items-center justify-center ml-4 flex-shrink-0">
                  <Headphones className="w-6 h-6 text-white" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-gray-800 mb-1">درس‌های اخلاق اسلامی - جلسه دوم</h3>
                  <div className="flex justify-between items-center text-sm text-gray-500">
                    <span>دکتر علوی</span>
                    <span>۵۰ دقیقه</span>
                  </div>
                </div>
                <Button variant="ghost" size="icon" className="h-10 w-10 flex-shrink-0">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-[#0a5c45] border-b-[8px] border-b-transparent"></div>
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* Pagination */}
        <div className="flex justify-center mt-8">
          <div className="flex space-x-1 rtl:space-x-reverse">
            <Button variant="outline" size="sm" disabled>
              قبلی
            </Button>
            <Button variant="outline" size="sm" className="bg-[#0a5c45] text-white">
              ۱
            </Button>
            <Button variant="outline" size="sm">
              ۲
            </Button>
            <Button variant="outline" size="sm">
              ۳
            </Button>
            <Button variant="outline" size="sm">
              ۴
            </Button>
            <Button variant="outline" size="sm">
              ۵
            </Button>
            <Button variant="outline" size="sm">
              بعدی
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

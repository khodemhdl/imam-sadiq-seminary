import { Card } from "@/components/ui/card"
import { Users, FileText, Video, Calendar, Bell, TrendingUp, BookOpen, MessageSquare } from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-800 mb-6">پنل مدیریت</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center ml-4">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">کاربران</p>
              <h3 className="text-2xl font-bold">۱,۲۵۴</h3>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center ml-4">
              <FileText className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">مقالات</p>
              <h3 className="text-2xl font-bold">۱۴۷</h3>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-amber-100 rounded-full flex items-center justify-center ml-4">
              <Video className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">ویدیوها</p>
              <h3 className="text-2xl font-bold">۸۹</h3>
            </div>
          </div>
        </Card>

        <Card className="p-6">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center ml-4">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-500">بازدید امروز</p>
              <h3 className="text-2xl font-bold">۳,۴۵۶</h3>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quick Actions */}
        <Card className="p-6 col-span-1">
          <h2 className="text-lg font-bold text-gray-800 mb-4">دسترسی سریع</h2>
          <div className="grid grid-cols-2 gap-3">
            <Link
              href="/admin/posts/new"
              className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
            >
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                  <FileText className="w-5 h-5 text-[#0a5c45]" />
                </div>
                <span className="text-sm">مقاله جدید</span>
              </div>
            </Link>
            <Link
              href="/admin/announcements/new"
              className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
            >
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                  <Bell className="w-5 h-5 text-[#0a5c45]" />
                </div>
                <span className="text-sm">اطلاعیه جدید</span>
              </div>
            </Link>
            <Link
              href="/admin/events/new"
              className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
            >
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                  <Calendar className="w-5 h-5 text-[#0a5c45]" />
                </div>
                <span className="text-sm">رویداد جدید</span>
              </div>
            </Link>
            <Link
              href="/admin/media/new"
              className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
            >
              <div className="flex flex-col items-center">
                <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                  <Video className="w-5 h-5 text-[#0a5c45]" />
                </div>
                <span className="text-sm">رسانه جدید</span>
              </div>
            </Link>
          </div>
        </Card>

        {/* Recent Activity */}
        <Card className="p-6 col-span-2">
          <h2 className="text-lg font-bold text-gray-800 mb-4">فعالیت‌های اخیر</h2>
          <div className="space-y-4">
            <div className="flex items-start">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                <FileText className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium">مقاله جدید منتشر شد</p>
                <p className="text-xs text-gray-500">توسط: دکتر محمدی - ۱۵ دقیقه پیش</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                <Users className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium">کاربر جدید ثبت نام کرد</p>
                <p className="text-xs text-gray-500">نام: علی حسینی - ۳۰ دقیقه پیش</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-10 h-10 bg-amber-100 rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                <Bell className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <p className="text-sm font-medium">اطلاعیه جدید منتشر شد</p>
                <p className="text-xs text-gray-500">عنوان: تغییر زمان کلاس‌ها - ۱ ساعت پیش</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                <MessageSquare className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <p className="text-sm font-medium">دیدگاه جدید دریافت شد</p>
                <p className="text-xs text-gray-500">روی: مقاله اصول فقه - ۲ ساعت پیش</p>
              </div>
            </div>

            <div className="flex items-start">
              <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center ml-3 flex-shrink-0">
                <BookOpen className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <p className="text-sm font-medium">دوره جدید اضافه شد</p>
                <p className="text-xs text-gray-500">عنوان: آشنایی با علوم حدیث - ۳ ساعت پیش</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft, Save, ImageIcon, FileUp, Eye, Clock, Calendar } from "lucide-react"
import Link from "next/link"

export default function NewPost() {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">ایجاد مقاله جدید</h1>
        <Link href="/admin/posts">
          <Button variant="outline" className="flex items-center">
            <ArrowLeft className="ml-2 w-4 h-4" />
            بازگشت به لیست
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">عنوان مقاله</Label>
                <Input id="title" placeholder="عنوان مقاله را وارد کنید..." className="mt-1" />
              </div>

              <div>
                <Label htmlFor="excerpt">خلاصه مقاله</Label>
                <Textarea
                  id="excerpt"
                  placeholder="خلاصه‌ای از مقاله را وارد کنید..."
                  className="mt-1 resize-none"
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="content">محتوای مقاله</Label>
                <div className="border rounded-md mt-1 overflow-hidden">
                  <div className="bg-gray-50 border-b p-2 flex items-center gap-2">
                    <Button variant="ghost" size="sm" className="h-8">
                      عنوان
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8">
                      پاراگراف
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8">
                      لیست
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8">
                      لینک
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8">
                      <Image className="w-4 h-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8">
                      <FileUp className="w-4 h-4" />
                    </Button>
                  </div>
                  <Textarea
                    id="content"
                    placeholder="محتوای مقاله را وارد کنید..."
                    className="border-0 rounded-none resize-none"
                    rows={15}
                  />
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">تصویر شاخص</h3>
            <div className="border-2 border-dashed rounded-md p-8 text-center">
              <div className="flex flex-col items-center">
                <ImageIcon className="w-16 h-16 text-gray-400 mb-4" />
                <p className="text-sm text-gray-500 mb-2">تصویر شاخص مقاله را اینجا بکشید و رها کنید</p>
                <p className="text-xs text-gray-400 mb-4">یا</p>
                <Button size="sm">انتخاب تصویر</Button>
                <p className="text-xs text-gray-400 mt-2">حداکثر سایز: 2MB - فرمت‌های مجاز: JPG، PNG</p>
              </div>
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">انتشار</h3>
            <div className="space-y-4">
              <div>
                <Label htmlFor="status">وضعیت</Label>
                <Select>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="انتخاب وضعیت" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="published">منتشر شده</SelectItem>
                    <SelectItem value="draft">پیش‌نویس</SelectItem>
                    <SelectItem value="pending">در انتظار بررسی</SelectItem>
                    <SelectItem value="private">خصوصی</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="publishDate">تاریخ انتشار</Label>
                <div className="relative mt-1">
                  <Input id="publishDate" placeholder="۱۴۰۲/۱۲/۱۵" />
                  <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
              </div>

              <div>
                <Label htmlFor="publishTime">زمان انتشار</Label>
                <div className="relative mt-1">
                  <Input id="publishTime" placeholder="۱۴:۳۰" />
                  <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                </div>
              </div>

              <div className="pt-4 flex gap-2">
                <Button className="bg-[#0a5c45] hover:bg-[#0a5c45]/90 flex-1">
                  <Save className="ml-2 w-4 h-4" />
                  ذخیره
                </Button>
                <Button variant="outline" className="flex items-center">
                  <Eye className="ml-2 w-4 h-4" />
                  پیش‌نمایش
                </Button>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">دسته‌بندی</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="cat1" className="ml-2" />
                <Label htmlFor="cat1" className="text-sm">
                  فقه و اصول
                </Label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="cat2" className="ml-2" />
                <Label htmlFor="cat2" className="text-sm">
                  تفسیر و علوم قرآنی
                </Label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="cat3" className="ml-2" />
                <Label htmlFor="cat3" className="text-sm">
                  کلام و فلسفه اسلامی
                </Label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="cat4" className="ml-2" />
                <Label htmlFor="cat4" className="text-sm">
                  حدیث و سیره
                </Label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="cat5" className="ml-2" />
                <Label htmlFor="cat5" className="text-sm">
                  اخلاق و عرفان
                </Label>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-lg font-medium mb-4">برچسب‌ها</h3>
            <div>
              <Input placeholder="برچسب‌ها را با کاما جدا کنید..." />
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full flex items-center">
                  فقه
                  <button className="ml-1 text-gray-500 hover:text-gray-700">×</button>
                </span>
                <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full flex items-center">
                  اصول
                  <button className="ml-1 text-gray-500 hover:text-gray-700">×</button>
                </span>
                <span className="bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded-full flex items-center">
                  علامه طباطبایی
                  <button className="ml-1 text-gray-500 hover:text-gray-700">×</button>
                </span>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

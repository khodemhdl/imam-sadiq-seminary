import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Plus, Edit, Trash, Eye, Filter, ArrowUpDown } from "lucide-react"
import Link from "next/link"

export default function PostsManagement() {
  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-gray-800">مدیریت مقالات</h1>
        <Link href="/admin/posts/new">
          <Button className="bg-[#0a5c45] hover:bg-[#0a5c45]/90">
            <Plus className="ml-2 w-4 h-4" />
            مقاله جدید
          </Button>
        </Link>
      </div>

      <Card className="mb-6">
        <div className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-grow">
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input placeholder="جستجو در مقالات..." className="pr-10 w-full" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex items-center">
                <Filter className="ml-2 w-4 h-4" />
                فیلتر
              </Button>
              <Button variant="outline" className="flex items-center">
                <ArrowUpDown className="ml-2 w-4 h-4" />
                مرتب‌سازی
              </Button>
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <div className="p-4">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12 text-right">#</TableHead>
                <TableHead className="text-right">عنوان مقاله</TableHead>
                <TableHead className="text-right">دسته‌بندی</TableHead>
                <TableHead className="text-right">نویسنده</TableHead>
                <TableHead className="text-right">تاریخ انتشار</TableHead>
                <TableHead className="text-right">وضعیت</TableHead>
                <TableHead className="text-right">عملیات</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell>۱</TableCell>
                <TableCell className="font-medium">بررسی تطبیقی آرای علامه طباطبایی و شهید مطهری</TableCell>
                <TableCell>فلسفه اسلامی</TableCell>
                <TableCell>دکتر محمدی</TableCell>
                <TableCell>۱۴۰۲/۱۲/۰۱</TableCell>
                <TableCell>
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">منتشر شده</span>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>۲</TableCell>
                <TableCell className="font-medium">تحلیلی بر روش‌های استنباط احکام فقهی</TableCell>
                <TableCell>فقه و اصول</TableCell>
                <TableCell>دکتر رضایی</TableCell>
                <TableCell>۱۴۰۲/۱۱/۲۵</TableCell>
                <TableCell>
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">منتشر شده</span>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>۳</TableCell>
                <TableCell className="font-medium">جایگاه عقل در استنباط احکام شرعی</TableCell>
                <TableCell>فقه و اصول</TableCell>
                <TableCell>دکتر حسینی</TableCell>
                <TableCell>۱۴۰۲/۱۱/۱۵</TableCell>
                <TableCell>
                  <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full">پیش‌نویس</span>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>۴</TableCell>
                <TableCell className="font-medium">بررسی تطبیقی مفهوم عدالت در اندیشه اسلامی</TableCell>
                <TableCell>فلسفه اسلامی</TableCell>
                <TableCell>دکتر علوی</TableCell>
                <TableCell>۱۴۰۲/۱۱/۰۵</TableCell>
                <TableCell>
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full">منتشر شده</span>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>

              <TableRow>
                <TableCell>۵</TableCell>
                <TableCell className="font-medium">روش‌شناسی تفسیر قرآن کریم</TableCell>
                <TableCell>تفسیر و علوم قرآنی</TableCell>
                <TableCell>دکتر موسوی</TableCell>
                <TableCell>۱۴۰۲/۱۰/۲۰</TableCell>
                <TableCell>
                  <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">غیرفعال</span>
                </TableCell>
                <TableCell>
                  <div className="flex space-x-2 rtl:space-x-reverse">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-red-500">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>

          <div className="flex items-center justify-between mt-4">
            <div className="text-sm text-gray-500">نمایش ۱ تا ۵ از ۲۵ مورد</div>
            <div className="flex space-x-1 rtl:space-x-reverse">
              <Button variant="outline" size="sm" disabled>
                قبلی
              </Button>
              <Button variant="outline" size="sm" className="bg-[#0a5c45] text-white">
                ۱
              </Button>
              <Button variant="outline" size="sm">
                ۲
              </Button>
              <Button variant="outline" size="sm">
                ۳
              </Button>
              <Button variant="outline" size="sm">
                ۴
              </Button>
              <Button variant="outline" size="sm">
                ۵
              </Button>
              <Button variant="outline" size="sm">
                بعدی
              </Button>
            </div>
          </div>
        </div>
      </Card>
    </div>
  )
}

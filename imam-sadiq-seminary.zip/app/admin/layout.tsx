import type React from "react"
import { Sidebar } from "@/components/admin/sidebar"
import { AdminGuard } from "@/components/auth/admin-guard"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <AdminGuard>
      <div className="flex min-h-screen bg-gray-100">
        <Sidebar />
        <div className="flex-1 p-8">{children}</div>
      </div>
    </AdminGuard>
  )
}

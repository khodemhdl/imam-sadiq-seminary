import { Input } from "@/components/ui/input"
import { ArrowRight, Calendar, Clock, User, Tag, Share2, Bookmark, MessageSquare, Eye } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"

export default function NewsDetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#0a5c45] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <Link href="/login" className="text-sm hover:underline">
              ورود کاربران
            </Link>
            <span className="text-xs">|</span>
            <Link href="/contact" className="text-sm hover:underline">
              تماس با ما
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse text-sm">
            <span>تاریخ: ۱۴۰۴/۰۳/۱۵</span>
            <span className="text-xs">|</span>
            <span>بسم الله الرحمن الرحیم</span>
          </div>
        </div>

        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-[#0a5c45] mr-3">
              <span className="text-2xl font-bold">خبر</span>
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold">پایگاه خبری مدرسه علمیه امام صادق (ع)</h1>
              <p className="text-sm text-white/80">آخرین اخبار و رویدادهای علمی و فرهنگی</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="bg-[#064835] border-t border-white/10 hidden md:block">
          <div className="container mx-auto px-4">
            <ul className="flex space-x-1 rtl:space-x-reverse">
              <li className="py-3 px-4 font-medium text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                <Link href="/news">صفحه اصلی</Link>
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                اخبار علمی
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                اخبار فرهنگی
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                رویدادها
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">مقالات</li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                گالری تصاویر
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                درباره ما
              </li>
            </ul>
          </div>
        </nav>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center mb-6">
          <Link href="/news" className="text-[#0a5c45] hover:underline flex items-center">
            <ArrowRight className="ml-2 w-4 h-4" />
            بازگشت به صفحه اخبار
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
              <h1 className="text-2xl font-bold text-gray-800 mb-4">
                برگزاری نشست علمی «چالش‌های اجتهاد در عصر حاضر» با حضور اساتید برجسته حوزه و دانشگاه
              </h1>

              <div className="flex flex-wrap items-center text-sm text-gray-500 mb-6 gap-4">
                <div className="flex items-center">
                  <Calendar className="ml-1 w-4 h-4" />
                  <span>۱۴۰۴/۰۳/۱۴</span>
                </div>
                <div className="flex items-center">
                  <User className="ml-1 w-4 h-4" />
                  <span>خبرنگار پایگاه خبری</span>
                </div>
                <div className="flex items-center">
                  <Tag className="ml-1 w-4 h-4" />
                  <span>رویداد</span>
                </div>
                <div className="flex items-center">
                  <Eye className="ml-1 w-4 h-4" />
                  <span>۴۵۶ بازدید</span>
                </div>
              </div>

              <div className="relative aspect-[2/1] rounded-lg overflow-hidden mb-6">
                <Image
                  src="/placeholder.svg?height=400&width=800"
                  alt="تصویر خبر"
                  width={800}
                  height={400}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="prose prose-lg max-w-none leading-relaxed">
                <p>
                  به گزارش پایگاه خبری مدرسه علمیه امام صادق (ع)، نشست علمی «چالش‌های اجتهاد در عصر حاضر» با حضور اساتید
                  برجسته حوزه و دانشگاه در تاریخ ۱۴ خرداد ۱۴۰۴ در سالن همایش‌های مدرسه علمیه امام صادق (ع) برگزار شد.
                </p>

                <p>
                  این نشست علمی با هدف بررسی چالش‌های پیش روی اجتهاد در عصر حاضر و ارائه راهکارهای مناسب برای مواجهه با
                  این چالش‌ها برگزار شد. در این نشست، اساتید برجسته حوزه و دانشگاه به ایراد سخنرانی پرداختند و دیدگاه‌های
                  خود را در این زمینه مطرح کردند.
                </p>

                <p>
                  حجت‌الاسلام والمسلمین دکتر محمدی، رئیس مدرسه علمیه امام صادق (ع)، در ابتدای این نشست ضمن خوشامدگویی به
                  حاضران، به اهمیت اجتهاد در عصر حاضر اشاره کرد و گفت: «اجتهاد به عنوان یکی از مهم‌ترین ابزارهای استنباط
                  احکام شرعی، همواره مورد توجه علمای اسلام بوده است. در عصر حاضر، با توجه به پیچیدگی‌های زندگی مدرن و
                  ظهور مسائل مستحدثه، نیاز به اجتهاد پویا و روزآمد بیش از پیش احساس می‌شود.»
                </p>

                <p>
                  در ادامه، آیت‌الله دکتر رضایی، از اساتید برجسته حوزه علمیه قم، به تبیین چالش‌های اجتهاد در عصر حاضر
                  پرداخت و گفت: «یکی از مهم‌ترین چالش‌های اجتهاد در عصر حاضر، مواجهه با مسائل مستحدثه‌ای است که در گذشته
                  سابقه نداشته‌اند. مسائلی همچون شبیه‌سازی، تغییر جنسیت، پیوند اعضا، بانکداری الکترونیک، ارزهای دیجیتال و
                  بسیاری از مسائل دیگر که نیازمند اجتهاد جدید و روزآمد هستند.»
                </p>

                <p>
                  دکتر حسینی، استاد دانشگاه و پژوهشگر حوزه فقه و اصول، نیز در سخنرانی خود به نقش علوم میان‌رشته‌ای در
                  اجتهاد معاصر اشاره کرد و گفت: «امروزه، اجتهاد نیازمند بهره‌گیری از علوم میان‌رشته‌ای است. مجتهد معاصر
                  علاوه بر تسلط بر علوم اسلامی، باید با علوم جدید نیز آشنایی داشته باشد تا بتواند به درستی مسائل مستحدثه
                  را تحلیل کند و حکم شرعی آن‌ها را استنباط نماید.»
                </p>

                <p>
                  در بخش دیگری از این نشست، میزگردی با حضور اساتید و کارشناسان برگزار شد و به سؤالات حاضران پاسخ داده
                  شد. در این میزگرد، چالش‌های اجتهاد در عصر حاضر از زوایای مختلف مورد بررسی قرار گرفت و راهکارهایی برای
                  مواجهه با این چالش‌ها ارائه شد.
                </p>

                <p>
                  در پایان این نشست، از کتاب «اجتهاد در عصر حاضر؛ چالش‌ها و راهکارها» که توسط انتشارات مدرسه علمیه امام
                  صادق (ع) منتشر شده است، رونمایی شد. این کتاب، مجموعه مقالاتی از اساتید برجسته حوزه و دانشگاه در زمینه
                  اجتهاد معاصر است که به بررسی چالش‌های اجتهاد در عصر حاضر و ارائه راهکارهایی برای مواجهه با این چالش‌ها
                  پرداخته است.
                </p>

                <p>
                  گفتنی است، این نشست با استقبال گسترده طلاب، دانشجویان و اساتید حوزه و دانشگاه مواجه شد و قرار است
                  مجموعه‌ای از سخنرانی‌های ارائه شده در این نشست، در قالب کتاب و لوح فشرده منتشر شود.
                </p>
              </div>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mt-8">
                <span className="text-gray-600 ml-2">برچسب‌ها:</span>
                <Link
                  href="/news/tag/ijtihad"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  اجتهاد
                </Link>
                <Link
                  href="/news/tag/seminary"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  حوزه علمیه
                </Link>
                <Link
                  href="/news/tag/fiqh"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  فقه و اصول
                </Link>
                <Link
                  href="/news/tag/conference"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  همایش علمی
                </Link>
              </div>

              {/* Share */}
              <div className="flex justify-between items-center mt-8 pt-6 border-t border-gray-100">
                <div className="flex space-x-4 rtl:space-x-reverse">
                  <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                    <Share2 className="ml-1 w-5 h-5" />
                    <span>اشتراک‌گذاری</span>
                  </button>
                  <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                    <Bookmark className="ml-1 w-5 h-5" />
                    <span>ذخیره</span>
                  </button>
                </div>
                <div>
                  <button className="flex items-center text-gray-600 hover:text-[#0a5c45]">
                    <MessageSquare className="ml-1 w-5 h-5" />
                    <span>نظرات (۱۲)</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Comments */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
              <h3 className="text-xl font-bold text-gray-800 mb-6">نظرات (۱۲)</h3>

              {/* Comment Form */}
              <div className="mb-8">
                <h4 className="text-lg font-medium text-gray-800 mb-4">ارسال نظر</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <input
                        type="text"
                        placeholder="نام شما"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0a5c45]"
                      />
                    </div>
                    <div>
                      <input
                        type="email"
                        placeholder="ایمیل شما"
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0a5c45]"
                      />
                    </div>
                  </div>
                  <div>
                    <Textarea
                      placeholder="نظر خود را بنویسید..."
                      className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#0a5c45]"
                      rows={5}
                    />
                  </div>
                  <div>
                    <Button className="bg-[#0a5c45] hover:bg-[#0a5c45]/90">ارسال نظر</Button>
                  </div>
                </div>
              </div>

              {/* Comment List */}
              <div className="space-y-6">
                {/* Comment 1 */}
                <div className="border-b border-gray-100 pb-6">
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 ml-4 flex-shrink-0">
                      <span className="text-lg font-bold">م</span>
                    </div>
                    <div>
                      <div className="flex items-center mb-2">
                        <h4 className="font-bold text-gray-800">محمد رضایی</h4>
                        <span className="mx-2 text-gray-400">|</span>
                        <span className="text-xs text-gray-500">۱۴۰۴/۰۳/۱۴</span>
                      </div>
                      <p className="text-gray-600 text-sm">
                        نشست بسیار مفیدی بود. مباحث مطرح شده در این نشست، به خوبی چالش‌های اجتهاد در عصر حاضر را تبیین
                        کرد و راهکارهای مناسبی برای مواجهه با این چالش‌ها ارائه داد. امیدوارم این گونه نشست‌ها تداوم داشته
                        باشد.
                      </p>
                      <button className="text-[#0a5c45] text-sm mt-2 hover:underline">پاسخ</button>
                    </div>
                  </div>

                  {/* Reply */}
                  <div className="flex items-start mt-4 mr-16">
                    <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 ml-4 flex-shrink-0">
                      <span className="text-lg font-bold">ا</span>
                    </div>
                    <div>
                      <div className="flex items-center mb-2">
                        <h4 className="font-bold text-gray-800">ادمین سایت</h4>
                        <span className="mx-2 text-gray-400">|</span>
                        <span className="text-xs text-gray-500">۱۴۰۴/۰۳/۱۴</span>
                      </div>
                      <p className="text-gray-600 text-sm">
                        با سلام و تشکر از نظر شما. بله، این نشست‌ها به صورت منظم برگزار خواهد شد و اطلاع‌رسانی آن از طریق
                        همین پایگاه خبری انجام می‌شود.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Comment 2 */}
                <div className="border-b border-gray-100 pb-6">
                  <div className="flex items-start">
                    <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center text-gray-600 ml-4 flex-shrink-0">
                      <span className="text-lg font-bold">ع</span>
                    </div>
                    <div>
                      <div className="flex items-center mb-2">
                        <h4 className="font-bold text-gray-800">علی حسینی</h4>
                        <span className="mx-2 text-gray-400">|</span>
                        <span className="text-xs text-gray-500">۱۴۰۴/۰۳/۱۴</span>
                      </div>
                      <p className="text-gray-600 text-sm">
                        آیا فایل صوتی یا تصویری این نشست منتشر خواهد شد؟ متأسفانه نتوانستم در این نشست شرکت کنم و
                        علاقه‌مند هستم که مباحث مطرح شده را بشنوم.
                      </p>
                      <button className="text-[#0a5c45] text-sm mt-2 hover:underline">پاسخ</button>
                    </div>
                  </div>
                </div>

                {/* More Comments Button */}
                <div className="text-center">
                  <Button variant="outline" className="text-[#0a5c45]">
                    مشاهده نظرات بیشتر
                  </Button>
                </div>
              </div>
            </div>

            {/* Related News */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-6">اخبار مرتبط</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex">
                  <div className="w-24 h-24 bg-gray-100 rounded-md overflow-hidden ml-4 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=96&width=96"
                      alt="تصویر خبر"
                      width={96}
                      height={96}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-1 hover:text-[#0a5c45]">
                      <Link href="#">انتشار کتاب «اجتهاد در عصر حاضر؛ چالش‌ها و راهکارها»</Link>
                    </h4>
                    <p className="text-sm text-gray-500 mb-1">خبرنگار پایگاه خبری</p>
                    <p className="text-xs text-gray-400">۱۴۰۴/۰۳/۱۰</p>
                  </div>
                </div>

                <div className="flex">
                  <div className="w-24 h-24 bg-gray-100 rounded-md overflow-hidden ml-4 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=96&width=96"
                      alt="تصویر خبر"
                      width={96}
                      height={96}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 mb-1 hover:text-[#0a5c45]">
                      <Link href="#">برگزاری کارگاه آموزشی «روش‌شناسی اجتهاد» ویژه طلاب</Link>
                    </h4>
                    <p className="text-sm text-gray-500 mb-1">خبرنگار پایگاه خبری</p>
                    <p className="text-xs text-gray-400">۱۴۰۴/۰۲/۲۵</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Most Viewed News */}
            <div className="bg-white rounded-lg shadow-sm p-5">
              <h3 className="text-lg font-bold text-[#0a5c45] mb-4 flex items-center">
                <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                پربازدیدترین اخبار
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">دیدار رئیس مدرسه علمیه امام صادق (ع) با آیت‌الله العظمی سیستانی</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۴</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۱۲۵۶</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">انتشار کتاب جدید «روش‌شناسی تفسیر قرآن» توسط انتشارات مدرسه</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۲</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۸۵۶</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">برگزاری مراسم جشن میلاد امام رضا (ع) با حضور طلاب و اساتید</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۰</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۷۲۳</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Tags */}
            <div className="bg-white rounded-lg shadow-sm p-5">
              <h3 className="text-lg font-bold text-[#0a5c45] mb-4 flex items-center">
                <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                برچسب‌های پرکاربرد
              </h3>
              <div className="flex flex-wrap gap-2">
                <Link
                  href="/news/tag/fiqh"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  فقه و اصول
                </Link>
                <Link
                  href="/news/tag/quran"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  تفسیر قرآن
                </Link>
                <Link
                  href="/news/tag/ethics"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  اخلاق اسلامی
                </Link>
                <Link
                  href="/news/tag/philosophy"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  فلسفه اسلامی
                </Link>
                <Link
                  href="/news/tag/hadith"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  حدیث و سیره
                </Link>
                <Link
                  href="/news/tag/seminary"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  حوزه علمیه
                </Link>
                <Link
                  href="/news/tag/research"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  پژوهش
                </Link>
              </div>
            </div>

            {/* Newsletter */}
            <div className="bg-[#0a5c45] rounded-lg shadow-sm p-5 text-white">
              <h3 className="text-lg font-bold mb-4">عضویت در خبرنامه</h3>
              <p className="text-white/80 text-sm mb-4">
                برای دریافت آخرین اخبار و رویدادهای مدرسه علمیه امام صادق (ع)، ایمیل خود را وارد کنید.
              </p>
              <div className="flex">
                <Input
                  type="email"
                  placeholder="ایمیل خود را وارد کنید..."
                  className="bg-white/20 border-white/30 text-white placeholder-white/70 rounded-l-none"
                />
                <Button className="bg-white text-[#0a5c45] hover:bg-white/90 rounded-r-none">عضویت</Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#0a5c45] text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-bold mb-4">درباره پایگاه خبری</h4>
              <p className="text-white/80 text-sm leading-relaxed">
                پایگاه خبری مدرسه علمیه امام صادق (ع) با هدف اطلاع‌رسانی دقیق و به‌روز از رویدادها و فعالیت‌های علمی،
                فرهنگی و آموزشی این مرکز راه‌اندازی شده است. این پایگاه خبری تلاش می‌کند تا با انعکاس اخبار و رویدادهای
                مهم، پل ارتباطی مناسبی بین مدرسه علمیه و مخاطبان آن باشد.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">ارتباط با ما</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>آدرس: استان آذربایجان غربی، نقده، خیابان امام، کوچه معبودی</li>
                <li>تلفن: ۰۲۱-۸۸۷۷۶۶۵۵</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">پیوندهای مفید</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>
                  <Link href="#" className="hover:text-white">
                    حوزه علمیه قم
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    پژوهشگاه علوم اسلامی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    کتابخانه دیجیتال تخصصی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    سامانه پاسخگویی به سؤالات شرعی
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-6 text-center text-white/70 text-sm">
            تمامی حقوق این وب‌سایت متعلق به مدرسه علمیه امام صادق (ع) می‌باشد. © ۱۴۰۴
          </div>
        </div>
      </footer>
    </div>
  )
}

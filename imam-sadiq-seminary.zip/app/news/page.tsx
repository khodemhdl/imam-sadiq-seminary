import { Search, Clock, ChevronLeft, ArrowLeft, ArrowRight, Eye, MessageSquare } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

export default function NewsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-[#0a5c45] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <Link href="/login" className="text-sm hover:underline">
              ورود کاربران
            </Link>
            <span className="text-xs">|</span>
            <Link href="/contact" className="text-sm hover:underline">
              تماس با ما
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse text-sm">
            <span>تاریخ: ۱۴۰۴/۰۳/۱۵</span>
            <span className="text-xs">|</span>
            <span>بسم الله الرحمن الرحیم</span>
          </div>
        </div>

        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-[#0a5c45] mr-3">
              <span className="text-2xl font-bold">خبر</span>
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold">پایگاه خبری مدرسه علمیه امام صادق (ع)</h1>
              <p className="text-sm text-white/80">آخرین اخبار و رویدادهای علمی و فرهنگی</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="relative">
              <input
                type="text"
                placeholder="جستجو در اخبار..."
                className="bg-white/20 border border-white/30 rounded-lg py-2 px-4 pl-10 w-full md:w-64 text-sm focus:outline-none focus:ring-2 focus:ring-white/50 text-white placeholder-white/70"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 w-4 h-4" />
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="bg-[#064835] border-t border-white/10 hidden md:block">
          <div className="container mx-auto px-4">
            <ul className="flex space-x-1 rtl:space-x-reverse">
              <li className="py-3 px-4 font-medium text-white border-b-2 border-white">صفحه اصلی</li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                اخبار علمی
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                اخبار فرهنگی
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                رویدادها
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">مقالات</li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                گالری تصاویر
              </li>
              <li className="py-3 px-4 text-white/80 hover:text-white hover:bg-[#053c2d] transition-colors">
                درباره ما
              </li>
            </ul>
          </div>
        </nav>
      </header>

      {/* Breaking News */}
      <div className="bg-red-600 text-white py-2">
        <div className="container mx-auto px-4 flex items-center">
          <span className="bg-white text-red-600 px-3 py-1 rounded text-sm font-bold ml-4">خبر فوری</span>
          <div className="overflow-hidden relative flex-grow">
            <div className="whitespace-nowrap animate-marquee">
              برگزاری همایش بزرگ علوم اسلامی با حضور اساتید برجسته کشور در تاریخ ۲۵ خرداد ۱۴۰۴ در مدرسه علمیه امام صادق
              (ع) | ثبت نام دوره جدید تفسیر قرآن کریم از تاریخ ۱ تیر آغاز می‌شود | انتشار شماره جدید فصلنامه علمی-پژوهشی
              مطالعات اسلامی
            </div>
          </div>
        </div>
      </div>

      <main className="container mx-auto px-4 py-8">
        {/* Featured News */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-2">
            <div className="relative rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=400&width=800"
                alt="خبر ویژه"
                width={800}
                height={400}
                className="w-full h-[400px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
              <div className="absolute bottom-0 p-6">
                <span className="bg-red-600 text-white text-xs px-2 py-1 rounded mb-2 inline-block">ویژه</span>
                <h2 className="text-2xl font-bold text-white mb-2">
                  دیدار رئیس مدرسه علمیه امام صادق (ع) با آیت‌الله العظمی سیستانی
                </h2>
                <p className="text-white/80 mb-4">
                  در این دیدار که روز گذشته انجام شد، درباره مسائل مهم حوزه‌های علمیه و همکاری‌های علمی و فرهنگی گفتگو شد.
                </p>
                <div className="flex items-center text-white/70 text-sm">
                  <Clock className="ml-1 w-4 h-4" />
                  <span>۱۴۰۴/۰۳/۱۴</span>
                  <span className="mx-2">|</span>
                  <Eye className="ml-1 w-4 h-4" />
                  <span>۱۲۵۶ بازدید</span>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <Image
                src="/placeholder.svg?height=180&width=320"
                alt="خبر مهم"
                width={320}
                height={180}
                className="w-full h-[180px] object-cover"
              />
              <div className="p-4">
                <span className="bg-blue-600 text-white text-xs px-2 py-1 rounded mb-2 inline-block">علمی</span>
                <h3 className="font-bold text-gray-800 mb-2">
                  انتشار کتاب جدید «روش‌شناسی تفسیر قرآن» توسط انتشارات مدرسه
                </h3>
                <div className="flex items-center text-gray-500 text-xs">
                  <Clock className="ml-1 w-3 h-3" />
                  <span>۱۴۰۴/۰۳/۱۲</span>
                  <span className="mx-2">|</span>
                  <Eye className="ml-1 w-3 h-3" />
                  <span>۸۵۶ بازدید</span>
                </div>
              </div>
            </div>

            <div className="bg-white rounded-lg overflow-hidden shadow-sm">
              <Image
                src="/placeholder.svg?height=180&width=320"
                alt="خبر مهم"
                width={320}
                height={180}
                className="w-full h-[180px] object-cover"
              />
              <div className="p-4">
                <span className="bg-green-600 text-white text-xs px-2 py-1 rounded mb-2 inline-block">فرهنگی</span>
                <h3 className="font-bold text-gray-800 mb-2">
                  برگزاری مراسم جشن میلاد امام رضا (ع) با حضور طلاب و اساتید
                </h3>
                <div className="flex items-center text-gray-500 text-xs">
                  <Clock className="ml-1 w-3 h-3" />
                  <span>۱۴۰۴/۰۳/۱۰</span>
                  <span className="mx-2">|</span>
                  <Eye className="ml-1 w-3 h-3" />
                  <span>۷۲۳ بازدید</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* News Categories */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main News Column */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-[#0a5c45] flex items-center">
                  <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                  آخرین اخبار
                </h2>
                <Link href="/news/all" className="text-sm text-[#0a5c45] hover:underline flex items-center">
                  مشاهده همه
                  <ChevronLeft className="w-4 h-4" />
                </Link>
              </div>

              <div className="space-y-6">
                {/* News Item 1 */}
                <div className="flex flex-col md:flex-row border-b border-gray-100 pb-6">
                  <div className="w-full md:w-1/3 mb-4 md:mb-0 md:ml-4">
                    <Image
                      src="/placeholder.svg?height=180&width=320"
                      alt="تصویر خبر"
                      width={320}
                      height={180}
                      className="w-full h-[180px] object-cover rounded-lg"
                    />
                  </div>
                  <div className="w-full md:w-2/3">
                    <div className="flex items-center mb-2">
                      <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full ml-2">رویداد</span>
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۴/۰۳/۱۴
                      </span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2 text-lg">
                      <Link href="/news/1" className="hover:text-[#0a5c45]">
                        برگزاری نشست علمی «چالش‌های اجتهاد در عصر حاضر» با حضور اساتید برجسته حوزه و دانشگاه
                      </Link>
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      این نشست علمی با هدف بررسی چالش‌های پیش روی اجتهاد در عصر حاضر و ارائه راهکارهای مناسب برای مواجهه
                      با این چالش‌ها برگزار شد. در این نشست، اساتید برجسته حوزه و دانشگاه به ایراد سخنرانی پرداختند و
                      دیدگاه‌های خود را در این زمینه مطرح کردند.
                    </p>
                    <div className="flex justify-between items-center">
                      <Link href="/news/1" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                      <div className="flex items-center text-gray-500 text-xs">
                        <Eye className="ml-1 w-3 h-3" />
                        <span>۴۵۶ بازدید</span>
                        <span className="mx-2">|</span>
                        <MessageSquare className="ml-1 w-3 h-3" />
                        <span>۱۲ نظر</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* News Item 2 */}
                <div className="flex flex-col md:flex-row border-b border-gray-100 pb-6">
                  <div className="w-full md:w-1/3 mb-4 md:mb-0 md:ml-4">
                    <Image
                      src="/placeholder.svg?height=180&width=320"
                      alt="تصویر خبر"
                      width={320}
                      height={180}
                      className="w-full h-[180px] object-cover rounded-lg"
                    />
                  </div>
                  <div className="w-full md:w-2/3">
                    <div className="flex items-center mb-2">
                      <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full ml-2">آموزشی</span>
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۴/۰۳/۱۲
                      </span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2 text-lg">
                      <Link href="/news/2" className="hover:text-[#0a5c45]">
                        آغاز ثبت‌نام دوره‌های تابستانی مدرسه علمیه امام صادق (ع) از اول تیرماه
                      </Link>
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      به گزارش روابط عمومی مدرسه علمیه امام صادق (ع)، ثبت‌نام دوره‌های تابستانی این مدرسه از اول تیرماه
                      آغاز می‌شود. این دوره‌ها شامل کلاس‌های تفسیر قرآن، اصول فقه، فلسفه اسلامی، اخلاق و عرفان، و زبان عربی
                      است که توسط اساتید مجرب برگزار می‌شود.
                    </p>
                    <div className="flex justify-between items-center">
                      <Link href="/news/2" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                      <div className="flex items-center text-gray-500 text-xs">
                        <Eye className="ml-1 w-3 h-3" />
                        <span>۳۸۹ بازدید</span>
                        <span className="mx-2">|</span>
                        <MessageSquare className="ml-1 w-3 h-3" />
                        <span>۸ نظر</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* News Item 3 */}
                <div className="flex flex-col md:flex-row border-b border-gray-100 pb-6">
                  <div className="w-full md:w-1/3 mb-4 md:mb-0 md:ml-4">
                    <Image
                      src="/placeholder.svg?height=180&width=320"
                      alt="تصویر خبر"
                      width={320}
                      height={180}
                      className="w-full h-[180px] object-cover rounded-lg"
                    />
                  </div>
                  <div className="w-full md:w-2/3">
                    <div className="flex items-center mb-2">
                      <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full ml-2">فرهنگی</span>
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۴/۰۳/۱۰
                      </span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2 text-lg">
                      <Link href="/news/3" className="hover:text-[#0a5c45]">
                        بازدید دانش‌آموزان مدارس شهرستان نقده از کتابخانه تخصصی مدرسه علمیه
                      </Link>
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      در راستای آشنایی دانش‌آموزان با علوم اسلامی و ترویج فرهنگ کتابخوانی، جمعی از دانش‌آموزان مدارس
                      شهرستان نقده از کتابخانه تخصصی مدرسه علمیه امام صادق (ع) بازدید کردند. در این بازدید، دانش‌آموزان
                      با بخش‌های مختلف کتابخانه و منابع ارزشمند آن آشنا شدند.
                    </p>
                    <div className="flex justify-between items-center">
                      <Link href="/news/3" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                      <div className="flex items-center text-gray-500 text-xs">
                        <Eye className="ml-1 w-3 h-3" />
                        <span>۲۷۵ بازدید</span>
                        <span className="mx-2">|</span>
                        <MessageSquare className="ml-1 w-3 h-3" />
                        <span>۵ نظر</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* News Item 4 */}
                <div className="flex flex-col md:flex-row">
                  <div className="w-full md:w-1/3 mb-4 md:mb-0 md:ml-4">
                    <Image
                      src="/placeholder.svg?height=180&width=320"
                      alt="تصویر خبر"
                      width={320}
                      height={180}
                      className="w-full h-[180px] object-cover rounded-lg"
                    />
                  </div>
                  <div className="w-full md:w-2/3">
                    <div className="flex items-center mb-2">
                      <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full ml-2">پژوهشی</span>
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۴/۰۳/۰۸
                      </span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2 text-lg">
                      <Link href="/news/4" className="hover:text-[#0a5c45]">
                        انتشار شماره جدید فصلنامه علمی-پژوهشی مطالعات اسلامی با محوریت اخلاق کاربردی
                      </Link>
                    </h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">
                      شماره جدید فصلنامه علمی-پژوهشی مطالعات اسلامی با محوریت اخلاق کاربردی منتشر شد. در این شماره،
                      مقالاتی با موضوعات اخلاق پزشکی، اخلاق رسانه، اخلاق تجارت و اخلاق زیست‌محیطی از دیدگاه اسلام به چاپ
                      رسیده است.
                    </p>
                    <div className="flex justify-between items-center">
                      <Link href="/news/4" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                      <div className="flex items-center text-gray-500 text-xs">
                        <Eye className="ml-1 w-3 h-3" />
                        <span>۲۱۰ بازدید</span>
                        <span className="mx-2">|</span>
                        <MessageSquare className="ml-1 w-3 h-3" />
                        <span>۳ نظر</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-center mt-8">
                <Button variant="outline" size="sm" className="mx-1">
                  <ArrowRight className="ml-2 w-4 h-4" />
                  قبلی
                </Button>
                <Button variant="outline" size="sm" className="mx-1 bg-[#0a5c45] text-white">
                  ۱
                </Button>
                <Button variant="outline" size="sm" className="mx-1">
                  ۲
                </Button>
                <Button variant="outline" size="sm" className="mx-1">
                  ۳
                </Button>
                <Button variant="outline" size="sm" className="mx-1">
                  ۴
                </Button>
                <Button variant="outline" size="sm" className="mx-1">
                  <ArrowLeft className="mr-2 w-4 h-4" />
                  بعدی
                </Button>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Most Viewed News */}
            <div className="bg-white rounded-lg shadow-sm p-5">
              <h3 className="text-lg font-bold text-[#0a5c45] mb-4 flex items-center">
                <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                پربازدیدترین اخبار
              </h3>
              <div className="space-y-4">
                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">دیدار رئیس مدرسه علمیه امام صادق (ع) با آیت‌الله العظمی سیستانی</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۴</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۱۲۵۶</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">انتشار کتاب جدید «روش‌شناسی تفسیر قرآن» توسط انتشارات مدرسه</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۲</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۸۵۶</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">برگزاری مراسم جشن میلاد امام رضا (ع) با حضور طلاب و اساتید</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۰</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۷۲۳</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden ml-3 flex-shrink-0">
                    <Image
                      src="/placeholder.svg?height=80&width=80"
                      alt="تصویر خبر"
                      width={80}
                      height={80}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800 text-sm hover:text-[#0a5c45]">
                      <Link href="#">برگزاری نشست علمی «چالش‌های اجتهاد در عصر حاضر»</Link>
                    </h4>
                    <div className="flex items-center mt-1 text-xs text-gray-500">
                      <Clock className="ml-1 w-3 h-3" />
                      <span>۱۴۰۴/۰۳/۱۴</span>
                      <span className="mx-1">|</span>
                      <Eye className="ml-1 w-3 h-3" />
                      <span>۴۵۶</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* News Categories */}
            <div className="bg-white rounded-lg shadow-sm p-5">
              <h3 className="text-lg font-bold text-[#0a5c45] mb-4 flex items-center">
                <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                دسته‌بندی اخبار
              </h3>
              <ul className="space-y-2">
                <li>
                  <Link
                    href="/news/category/scientific"
                    className="flex items-center justify-between text-gray-700 hover:text-[#0a5c45] py-2 border-b border-gray-100"
                  >
                    <span>اخبار علمی</span>
                    <span className="bg-gray-100 text-gray-600 text-xs rounded-full px-2 py-0.5">۴۲</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/news/category/cultural"
                    className="flex items-center justify-between text-gray-700 hover:text-[#0a5c45] py-2 border-b border-gray-100"
                  >
                    <span>اخبار فرهنگی</span>
                    <span className="bg-gray-100 text-gray-600 text-xs rounded-full px-2 py-0.5">۳۵</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/news/category/educational"
                    className="flex items-center justify-between text-gray-700 hover:text-[#0a5c45] py-2 border-b border-gray-100"
                  >
                    <span>اخبار آموزشی</span>
                    <span className="bg-gray-100 text-gray-600 text-xs rounded-full px-2 py-0.5">۲۸</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/news/category/research"
                    className="flex items-center justify-between text-gray-700 hover:text-[#0a5c45] py-2 border-b border-gray-100"
                  >
                    <span>اخبار پژوهشی</span>
                    <span className="bg-gray-100 text-gray-600 text-xs rounded-full px-2 py-0.5">۲۳</span>
                  </Link>
                </li>
                <li>
                  <Link
                    href="/news/category/events"
                    className="flex items-center justify-between text-gray-700 hover:text-[#0a5c45] py-2"
                  >
                    <span>رویدادها</span>
                    <span className="bg-gray-100 text-gray-600 text-xs rounded-full px-2 py-0.5">۱۹</span>
                  </Link>
                </li>
              </ul>
            </div>

            {/* Tags */}
            <div className="bg-white rounded-lg shadow-sm p-5">
              <h3 className="text-lg font-bold text-[#0a5c45] mb-4 flex items-center">
                <span className="ml-2 w-1 h-6 bg-[#0a5c45] inline-block"></span>
                برچسب‌های پرکاربرد
              </h3>
              <div className="flex flex-wrap gap-2">
                <Link
                  href="/news/tag/fiqh"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  فقه و اصول
                </Link>
                <Link
                  href="/news/tag/quran"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  تفسیر قرآن
                </Link>
                <Link
                  href="/news/tag/ethics"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  اخلاق اسلامی
                </Link>
                <Link
                  href="/news/tag/philosophy"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  فلسفه اسلامی
                </Link>
                <Link
                  href="/news/tag/hadith"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  حدیث و سیره
                </Link>
                <Link
                  href="/news/tag/seminary"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  حوزه علمیه
                </Link>
                <Link
                  href="/news/tag/research"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  پژوهش
                </Link>
                <Link
                  href="/news/tag/education"
                  className="bg-gray-100 text-gray-700 hover:bg-[#0a5c45] hover:text-white transition-colors text-xs px-3 py-1 rounded-full"
                >
                  آموزش
                </Link>
              </div>
            </div>

            {/* Newsletter */}
            <div className="bg-[#0a5c45] rounded-lg shadow-sm p-5 text-white">
              <h3 className="text-lg font-bold mb-4">عضویت در خبرنامه</h3>
              <p className="text-white/80 text-sm mb-4">
                برای دریافت آخرین اخبار و رویدادهای مدرسه علمیه امام صادق (ع)، ایمیل خود را وارد کنید.
              </p>
              <div className="flex">
                <Input
                  type="email"
                  placeholder="ایمیل خود را وارد کنید..."
                  className="bg-white/20 border-white/30 text-white placeholder-white/70 rounded-l-none"
                />
                <Button className="bg-white text-[#0a5c45] hover:bg-white/90 rounded-r-none">عضویت</Button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#0a5c45] text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-bold mb-4">درباره پایگاه خبری</h4>
              <p className="text-white/80 text-sm leading-relaxed">
                پایگاه خبری مدرسه علمیه امام صادق (ع) با هدف اطلاع‌رسانی دقیق و به‌روز از رویدادها و فعالیت‌های علمی،
                فرهنگی و آموزشی این مرکز راه‌اندازی شده است. این پایگاه خبری تلاش می‌کند تا با انعکاس اخبار و رویدادهای
                مهم، پل ارتباطی مناسبی بین مدرسه علمیه و مخاطبان آن باشد.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">ارتباط با ما</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>آدرس: استان آذربایجان غربی، نقده، خیابان امام، کوچه معبودی</li>
                <li>تلفن: ۰۲۱-۸۸۷۷۶۶۵۵</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">پیوندهای مفید</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>
                  <Link href="#" className="hover:text-white">
                    حوزه علمیه قم
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    پژوهشگاه علوم اسلامی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    کتابخانه دیجیتال تخصصی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    سامانه پاسخگویی به سؤالات شرعی
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-6 text-center text-white/70 text-sm">
            تمامی حقوق این وب‌سایت متعلق به مدرسه علمیه امام صادق (ع) می‌باشد. © ۱۴۰۴
          </div>
        </div>
      </footer>
    </div>
  )
}

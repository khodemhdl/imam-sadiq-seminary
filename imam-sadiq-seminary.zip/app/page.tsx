import { Search, Menu, ChevronLeft, Calendar, BookOpen, Video, FileText, Headphones, Clock } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Top Bar */}
      <div className="bg-[#0a5c45] text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            <Link href="/auth" className="text-sm hover:underline">
              پنل مدیریت
            </Link>
            <span className="text-xs">|</span>
            <Link href="/contact" className="text-sm hover:underline">
              تماس با ما
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-4 rtl:space-x-reverse text-sm">
            <span>تاریخ: ۱۴۰۴/۰۳/۱۵</span>
            <span className="text-xs">|</span>
            <span>بسم الله الرحمن الرحیم</span>
          </div>
        </div>
      </div>

      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-16 h-16 bg-[#0a5c45] rounded-full flex items-center justify-center text-white mr-3">
              <BookOpen className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold text-[#0a5c45]">مدرسه علمیه امام صادق (ع)</h1>
              <p className="text-sm text-gray-600">مرکز تخصصی آموزش علوم دینی و تربیت طلاب</p>
            </div>
          </div>

          <div className="flex items-center">
            <div className="relative">
              <input
                type="text"
                placeholder="جستجو..."
                className="bg-gray-100 rounded-lg py-2 px-4 pl-10 w-full md:w-64 text-sm focus:outline-none focus:ring-2 focus:ring-[#0a5c45]"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            </div>
            <button className="md:hidden ml-4 text-[#0a5c45]">
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Navigation */}
        <nav className="bg-gray-100 border-t border-b border-gray-200 hidden md:block">
          <div className="container mx-auto px-4">
            <ul className="flex space-x-1 rtl:space-x-reverse">
              <li className="py-3 px-4 font-medium text-[#0a5c45] border-b-2 border-[#0a5c45]">صفحه اصلی</li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                درباره ما
              </li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                اخبار و اطلاعیه‌ها
              </li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                مقالات علمی
              </li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                دروس و محتوای آموزشی
              </li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                کتابخانه
              </li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">گالری</li>
              <li className="py-3 px-4 text-gray-700 hover:text-[#0a5c45] hover:bg-gray-50 transition-colors">
                تماس با ما
              </li>
            </ul>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative h-[300px] md:h-[400px] overflow-hidden">
        <div className="absolute inset-0 bg-[#0a5c45]/80 z-10"></div>
        <Image
          src="/placeholder.svg?height=400&width=1920"
          alt="نمای مدرسه علمیه"
          width={1920}
          height={400}
          className="object-cover w-full h-full"
        />
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center text-white text-center px-4">
          <h2 className="text-2xl md:text-4xl font-bold mb-4">مدرسه علمیه امام صادق (ع)</h2>
          <p className="text-lg md:text-xl mb-6 max-w-2xl">
            مرکز تخصصی آموزش علوم دینی و تربیت طلاب با بیش از ۳۱ سال سابقه درخشان
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/register"
              className="bg-white text-[#0a5c45] px-6 py-2 rounded-md font-medium hover:bg-gray-100 transition-colors"
            >
              ثبت نام در دوره‌های آموزشی
            </Link>
            <Link
              href="/about"
              className="border border-white text-white px-6 py-2 rounded-md font-medium hover:bg-white/10 transition-colors"
            >
              آشنایی بیشتر با مدرسه
            </Link>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="flex-grow bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content - 2/3 width on desktop */}
            <div className="lg:col-span-2 space-y-8">
              {/* Announcements Section */}
              <section className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#0a5c45] flex items-center">
                    <Calendar className="ml-2 w-5 h-5" />
                    اطلاعیه‌ها و رویدادها
                  </h2>
                  <Link href="/announcements" className="text-sm text-[#0a5c45] hover:underline flex items-center">
                    مشاهده همه
                    <ChevronLeft className="w-4 h-4" />
                  </Link>
                </div>

                <div className="space-y-4">
                  {/* Announcement Item 1 */}
                  <div className="border border-gray-100 rounded-md p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between mb-2">
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۲/۱۲/۱۰
                      </span>
                      <span className="bg-[#0a5c45] text-white text-xs px-2 py-0.5 rounded">اطلاعیه مهم</span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">ثبت نام ترم تحصیلی جدید سال ۱۴۰۳-۱۴۰۲</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      به اطلاع کلیه طلاب و دانشجویان می‌رساند که ثبت نام ترم جدید از تاریخ ۱ مهر آغاز و تا ۱۵ مهر ادامه
                      خواهد داشت. متقاضیان می‌توانند با مراجعه به سامانه آموزشی نسبت به انتخاب واحد اقدام نمایند.
                    </p>
                    <div className="flex justify-end">
                      <Link href="/announcements/1" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                    </div>
                  </div>

                  {/* Announcement Item 2 */}
                  <div className="border border-gray-100 rounded-md p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between mb-2">
                      <span className="text-xs text-gray-500 flex items-center">
                        <Clock className="ml-1 w-3 h-3" />
                        ۱۴۰۲/۱۲/۰۵
                      </span>
                      <span className="bg-amber-500 text-white text-xs px-2 py-0.5 rounded">رویداد</span>
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">برگزاری همایش سالانه اصول فقه</h3>
                    <p className="text-sm text-gray-600 mb-3">
                      همایش سالانه اصول فقه با حضور اساتید برجسته حوزه و دانشگاه در تاریخ ۲۵ اسفندماه در سالن همایش‌های
                      مدرسه علمیه برگزار می‌گردد. علاقمندان می‌توانند جهت ثبت نام به دفتر روابط عمومی مراجعه نمایند.
                    </p>
                    <div className="flex justify-end">
                      <Link href="/announcements/2" className="text-[#0a5c45] text-sm hover:underline">
                        ادامه مطلب
                      </Link>
                    </div>
                  </div>
                </div>
              </section>

              {/* Latest Content Section */}
              <section className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#0a5c45] flex items-center">
                    <FileText className="ml-2 w-5 h-5" />
                    آخرین مطالب و مقالات
                  </h2>
                  <Link href="/articles" className="text-sm text-[#0a5c45] hover:underline flex items-center">
                    مشاهده همه
                    <ChevronLeft className="w-4 h-4" />
                  </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Article Item 1 */}
                  <div className="group">
                    <div className="aspect-video rounded-md overflow-hidden mb-3 bg-gray-100">
                      <Image
                        src="/placeholder.svg?height=200&width=400"
                        alt="تصویر مقاله"
                        width={400}
                        height={200}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500">۱۴۰۲/۱۲/۰۱</span>
                      <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                        بررسی تطبیقی آرای علامه طباطبایی و شهید مطهری در باب عدالت اجتماعی
                      </h3>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        این مقاله به بررسی تطبیقی دیدگاه‌های دو اندیشمند بزرگ معاصر در خصوص مفهوم عدالت اجتماعی از منظر
                        اسلام می‌پردازد...
                      </p>
                    </div>
                  </div>

                  {/* Article Item 2 */}
                  <div className="group">
                    <div className="aspect-video rounded-md overflow-hidden mb-3 bg-gray-100">
                      <Image
                        src="/placeholder.svg?height=200&width=400"
                        alt="تصویر مقاله"
                        width={400}
                        height={200}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div>
                      <span className="text-xs text-gray-500">۱۴۰۲/۱۱/۲۵</span>
                      <h3 className="font-bold text-gray-800 mb-2 group-hover:text-[#0a5c45] transition-colors">
                        تحلیلی بر روش‌های استنباط احکام فقهی در مسائل مستحدثه
                      </h3>
                      <p className="text-sm text-gray-600 line-clamp-2">
                        در این پژوهش، روش‌های نوین استنباط احکام شرعی در مواجهه با مسائل جدید و چالش‌های دنیای معاصر مورد
                        بررسی قرار گرفته است...
                      </p>
                    </div>
                  </div>
                </div>
              </section>

              {/* Multimedia Section */}
              <section className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-[#0a5c45] flex items-center">
                    <Video className="ml-2 w-5 h-5" />
                    محتوای چندرسانه‌ای
                  </h2>
                  <Link href="/multimedia" className="text-sm text-[#0a5c45] hover:underline flex items-center">
                    مشاهده همه
                    <ChevronLeft className="w-4 h-4" />
                  </Link>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {/* Video Item 1 */}
                  <div className="group">
                    <div className="aspect-video relative rounded-md overflow-hidden mb-2 bg-gray-800">
                      <Image
                        src="/placeholder.svg?height=180&width=320"
                        alt="تصویر ویدیو"
                        width={320}
                        height={180}
                        className="w-full h-full object-cover opacity-80 group-hover:opacity-70 transition-opacity"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:bg-[#0a5c45]/80 transition-colors">
                          <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-white border-b-[8px] border-b-transparent ml-1"></div>
                        </div>
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-800 group-hover:text-[#0a5c45] transition-colors">
                      جلسه اول: مبانی اصول فقه
                    </h3>
                    <span className="text-xs text-gray-500">استاد محمدی - ۵۵ دقیقه</span>
                  </div>

                  {/* Audio Item */}
                  <div className="group">
                    <div className="aspect-video relative rounded-md overflow-hidden mb-2 bg-gradient-to-r from-[#0a5c45]/90 to-[#0a5c45]/70">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Headphones className="w-12 h-12 text-white/80 group-hover:text-white transition-colors" />
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-800 group-hover:text-[#0a5c45] transition-colors">
                      سلسله مباحث تفسیر سوره بقره
                    </h3>
                    <span className="text-xs text-gray-500">استاد رضایی - جلسه سوم</span>
                  </div>

                  {/* Video Item 2 */}
                  <div className="group">
                    <div className="aspect-video relative rounded-md overflow-hidden mb-2 bg-gray-800">
                      <Image
                        src="/placeholder.svg?height=180&width=320"
                        alt="تصویر ویدیو"
                        width={320}
                        height={180}
                        className="w-full h-full object-cover opacity-80 group-hover:opacity-70 transition-opacity"
                      />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm group-hover:bg-[#0a5c45]/80 transition-colors">
                          <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[14px] border-l-white border-b-[8px] border-b-transparent ml-1"></div>
                        </div>
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-800 group-hover:text-[#0a5c45] transition-colors">
                      کارگاه روش تحقیق در علوم اسلامی
                    </h3>
                    <span className="text-xs text-gray-500">دکتر حسینی - ۷۵ دقیقه</span>
                  </div>
                </div>
              </section>
            </div>

            {/* Sidebar - 1/3 width on desktop */}
            <div className="space-y-6">
              {/* Quick Links */}
              <div className="bg-white rounded-lg shadow-sm p-5">
                <h3 className="text-lg font-bold text-[#0a5c45] mb-4">دسترسی سریع</h3>
                <div className="grid grid-cols-2 gap-3">
                  <Link
                    href="/register"
                    className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
                  >
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                        <BookOpen className="w-5 h-5 text-[#0a5c45]" />
                      </div>
                      <span className="text-sm">ثبت نام</span>
                    </div>
                  </Link>
                  <Link
                    href="/contact"
                    className="bg-gray-50 hover:bg-gray-100 transition-colors rounded-md p-3 text-center"
                  >
                    <div className="flex flex-col items-center">
                      <div className="w-10 h-10 bg-[#0a5c45]/10 rounded-full flex items-center justify-center mb-2">
                        <FileText className="w-5 h-5 text-[#0a5c45]" />
                      </div>
                      <span className="text-sm">تماس</span>
                    </div>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[#0a5c45] text-white py-8">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-bold mb-4">درباره مدرسه علمیه</h4>
              <p className="text-white/80 text-sm leading-relaxed">
                مدرسه علمیه امام صادق (ع) با هدف تربیت طلاب متخصص در علوم دینی و با رویکرد پاسخگویی به نیازهای جامعه
                اسلامی تأسیس شده است. این مرکز با بهره‌گیری از اساتید مجرب و منابع غنی علمی، محیطی مناسب برای رشد و تعالی
                علمی و معنوی طلاب فراهم آورده است.
              </p>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">ارتباط با ما</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>آدرس: استان آذربایجان غربی، نقده، خیابان امام، کوچه معبودی</li>
                <li>تلفن: ۰۴۴۳۵۶۲۵۶۰۲</li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-bold mb-4">پیوندهای مفید</h4>
              <ul className="space-y-2 text-white/80 text-sm">
                <li>
                  <Link href="#" className="hover:text-white">
                    حوزه علمیه قم
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    پژوهشگاه علوم اسلامی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    کتابخانه دیجیتال تخصصی
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white">
                    سامانه پاسخگویی به سؤالات شرعی
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/20 mt-8 pt-6 text-center text-white/70 text-sm">
            تمامی حقوق این وب‌سایت متعلق به مدرسه علمیه امام صادق (ع) می‌باشد. © ۱۴۰۴
          </div>
        </div>
      </footer>
    </div>
  )
}

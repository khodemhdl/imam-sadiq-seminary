"use client"

import { useSession, signOut } from "next-auth/react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { User, LogOut, Settings } from "lucide-react"

export function UserAuthNav() {
  const { data: session, status } = useSession()

  // Manejo seguro de la propiedad role
  const isAdmin = session?.user?.role === "admin"

  if (status === "loading") {
    return <div className="h-9 w-[100px] bg-gray-200/20 animate-pulse rounded"></div>
  }

  if (status === "unauthenticated" || !session) {
    return (
      <Link href="/auth" className="text-sm hover:underline">
        پنل مدیریت
      </Link>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-9 w-9 rounded-full">
          <User className="h-5 w-5" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <div className="flex items-center justify-start gap-2 p-2">
          <div className="flex flex-col space-y-0.5 leading-none">
            <p className="font-medium text-sm">{session.user?.name || "کاربر"}</p>
            <p className="text-xs text-muted-foreground">{session.user?.email || ""}</p>
          </div>
        </div>
        <DropdownMenuSeparator />
        {isAdmin && (
          <DropdownMenuItem asChild>
            <Link href="/admin" className="cursor-pointer w-full flex items-center">
              <Settings className="ml-2 h-4 w-4" />
              <span>پنل مدیریت</span>
            </Link>
          </DropdownMenuItem>
        )}
        <DropdownMenuItem
          onClick={() => signOut({ callbackUrl: "/auth" })}
          className="cursor-pointer text-red-600 focus:text-red-600"
        >
          <LogOut className="ml-2 h-4 w-4" />
          <span>خروج</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

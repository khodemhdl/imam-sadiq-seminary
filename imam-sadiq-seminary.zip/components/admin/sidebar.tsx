"use client"

import Link from "next/link"
import { Home, FileText, Video, Bell, Users, Settings, Calendar, BookOpen, LogOut } from "lucide-react"
import { usePathname } from "next/navigation"

export function Sidebar() {
  const pathname = usePathname()

  const isActive = (path: string) => {
    return pathname === path || pathname?.startsWith(`${path}/`)
  }

  return (
    <div className="w-64 bg-white border-l border-gray-200 h-screen sticky top-0 overflow-y-auto">
      <div className="p-6 border-b">
        <h2 className="text-xl font-bold text-[#0a5c45]">پنل مدیریت</h2>
        <p className="text-sm text-gray-500">مدرسه علمیه امام صادق (ع)</p>
      </div>

      <nav className="p-4">
        <ul className="space-y-1">
          <li>
            <Link
              href="/admin"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin") &&
                !isActive("/admin/posts") &&
                !isActive("/admin/announcements") &&
                !isActive("/admin/media") &&
                !isActive("/admin/events") &&
                !isActive("/admin/courses") &&
                !isActive("/admin/users") &&
                !isActive("/admin/settings")
                  ? "text-gray-700 bg-gray-100"
                  : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Home className="ml-2 w-5 h-5" />
              <span>داشبورد</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/posts"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/posts") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <FileText className="ml-2 w-5 h-5" />
              <span>مقالات</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/announcements"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/announcements") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Bell className="ml-2 w-5 h-5" />
              <span>اطلاعیه‌ها</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/media"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/media") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Video className="ml-2 w-5 h-5" />
              <span>رسانه‌ها</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/events"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/events") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Calendar className="ml-2 w-5 h-5" />
              <span>رویدادها</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/courses"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/courses") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <BookOpen className="ml-2 w-5 h-5" />
              <span>دوره‌های آموزشی</span>
            </Link>
          </li>

          <li>
            <Link
              href="/admin/users"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/users") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Users className="ml-2 w-5 h-5" />
              <span>کاربران</span>
            </Link>
          </li>

          <li className="pt-4 mt-4 border-t">
            <Link
              href="/admin/settings"
              className={`flex items-center px-4 py-2 rounded-md ${
                isActive("/admin/settings") ? "text-gray-700 bg-gray-100" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <Settings className="ml-2 w-5 h-5" />
              <span>تنظیمات</span>
            </Link>
          </li>

          <li>
            <Link href="/auth/logout" className="flex items-center px-4 py-2 text-red-600 hover:bg-red-50 rounded-md">
              <LogOut className="ml-2 w-5 h-5" />
              <span>خروج</span>
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  )
}

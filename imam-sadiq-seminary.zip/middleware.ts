import { NextResponse } from "next/server"
import { getToken } from "next-auth/jwt"
import type { NextRequest } from "next/server"

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // Rutas protegidas que requieren autenticación
  const protectedPaths = ["/admin"]
  const isPathProtected = protectedPaths.some((path) => pathname.startsWith(path))

  // Ruta de login
  const isAuthPage = pathname.startsWith("/auth")

  if (isPathProtected) {
    try {
      const token = await getToken({
        req: request,
        secret: process.env.NEXTAUTH_SECRET || "YOUR_SECRET_KEY",
      })

      // Si el usuario no ha iniciado sesión, redirigir a la página de inicio de sesión
      if (!token) {
        const url = new URL(`/auth/login`, request.url)
        url.searchParams.set("callbackUrl", encodeURI(pathname))
        return NextResponse.redirect(url)
      }

      // Verificar el rol del usuario (solo los administradores pueden acceder al panel de administración)
      if (pathname.startsWith("/admin") && token.role !== "admin") {
        return NextResponse.redirect(new URL("/auth", request.url))
      }
    } catch (error) {
      console.error("Middleware error:", error)
      // En caso de error, redirigir a la página de inicio
      return NextResponse.redirect(new URL("/", request.url))
    }
  }

  // Si el usuario ya está autenticado y trata de acceder a la página de login, redirigirlo al panel de administración
  if (isAuthPage && pathname !== "/auth") {
    try {
      const token = await getToken({
        req: request,
        secret: process.env.NEXTAUTH_SECRET || "YOUR_SECRET_KEY",
      })

      if (token && pathname === "/auth/login") {
        if (token.role === "admin") {
          return NextResponse.redirect(new URL("/admin", request.url))
        } else {
          return NextResponse.redirect(new URL("/auth", request.url))
        }
      }
    } catch (error) {
      console.error("Middleware error:", error)
    }
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*", "/auth/:path*"],
}

import { prisma } from "./prisma"
import { compare, hash } from "bcrypt"

export type UserCreateInput = {
  name: string
  email: string
  password: string
  role?: string
}

export type UserUpdateInput = {
  name?: string
  email?: string
  password?: string
  role?: string
}

export async function createUser(data: UserCreateInput) {
  const hashedPassword = await hash(data.password, 10)

  return prisma.user.create({
    data: {
      ...data,
      password: hashedPassword,
    },
  })
}

export async function getUserByEmail(email: string) {
  return prisma.user.findUnique({
    where: { email },
  })
}

export async function getUserById(id: string) {
  return prisma.user.findUnique({
    where: { id },
  })
}

export async function updateUser(id: string, data: UserUpdateInput) {
  const updateData = { ...data }

  if (data.password) {
    updateData.password = await hash(data.password, 10)
  }

  return prisma.user.update({
    where: { id },
    data: updateData,
  })
}

export async function deleteUser(id: string) {
  return prisma.user.delete({
    where: { id },
  })
}

export async function verifyPassword(user: { password: string }, inputPassword: string) {
  return compare(inputPassword, user.password)
}

export async function getAllUsers() {
  return prisma.user.findMany({
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
      createdAt: true,
      updatedAt: true,
      image: true,
    },
  })
}
